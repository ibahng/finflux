<!--README.md files serve as the main landing page on this directory's github repository. It is the first thing that a viewer sees when he or she enters the github repo.

-->

# Heading 1

## Heading 2

### Heading 3

#### Heading 4

##### Heading 5

###### Heading 6

<!--This is writing comments-->

#---------------------------------------------------------------------

normal text

*italic*

**bold**

***bold/italic***

~~strike through~~

<mark>highlight</mark>

FILLER<sup>superscript</sup>

FILLER<sub>subcript</sub>